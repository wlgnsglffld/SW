package com.test.cinema.system;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;

public class CinemaManagement {

    private HashSet<String> uniqueRegionList = new HashSet<>();
    private Scanner scan = new Scanner(System.in);
    private ArrayList<String> list = new ArrayList<>();
    private ArrayList<String> regionList = new ArrayList<>();
    private ArrayList<String> cinemaList = new ArrayList<>();
    private File cinemaFile = new File("C:\\DDGCinema_data\\영화관목록.txt");
    private File movieCinemaFile = new File("C:\\DDGCinema_data\\시스템_극장별 현재 상영 영화 목록.txt");
    private File movieFile = new File("C:\\DDGCinema_data\\시스템_현재 상영 영화 목록.txt");

    public void CinemaList() {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(cinemaFile));
            String line;

            uniqueRegionList.clear(); // 중복없이 유지하기 위해 초기화

            while ((line = reader.readLine()) != null) {
                list.add(line);
                String[] arrays = line.split("■");
                uniqueRegionList.add(arrays[0]);
            }

            reader.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        regionList.clear(); // 중복없는 지역 목록을 초기화

        for (String region : uniqueRegionList) {
            regionList.add(region);
        }

        while (true) {
            System.out.println("극장에서 상영할 영화를 관리할 수 있습니다.");
            System.out.println("지역을 선택하세요.");
            System.out.println("==============================");

            for (int i = 0; i < regionList.size(); i++) {
                System.out.printf("%d. %s\n", i + 1, regionList.get(i));
            }

            System.out.println("==============================");
            System.out.println("0. 뒤로가기");
            System.out.println("==============================");
            System.out.print("입력 : ");

            String input = scan.nextLine();

            switch (input) {
                case "0":
                    return;
                default:
                    cinemaSelect(regionList.get(Integer.parseInt(input) - 1));
                    break;
            }
        }
    }

    private void cinemaSelect(String selRegion) {
        cinemaList.clear();

        for (int i = 0; i < list.size(); i++) {
            String[] array = list.get(i).split("■");
            if (array.length > 1 && array[0].equals(selRegion)) {
                cinemaList.add(array[1]);
            }
        }

        while (true) {
            System.out.println("==============================");
            System.out.println("상영관을 선택하세요.");
            System.out.println("==============================");

            for (int i = 0; i < cinemaList.size(); i++) {
                System.out.printf("%d. %s\n", i + 1, cinemaList.get(i));
            }

            System.out.println("==============================");
            System.out.println("0. 뒤로가기");
            System.out.println("==============================");
            System.out.print("입력 : ");

            try {
                int input = Integer.parseInt(scan.nextLine());

                if (input == 0) {
                    break;
                } else if (input >= 1 && input <= cinemaList.size()) {
                    cinemaMovieList(cinemaList.get(input - 1));
                } else {
                    System.out.println("잘못된 입력입니다. 다시 입력해주세요.");
                }
            } catch (NumberFormatException e) {
                System.out.println("숫자를 입력해주세요.");
            }
        }
    }

    private void cinemaMovieList(String cinema) {
        while (true) {
            System.out.println("==============================");
            System.out.printf("[%s점] 현재 상영중인 영화 입니다.\n", cinema);
            System.out.println("==============================");

            try {
                BufferedReader movieReader = new BufferedReader(new FileReader(movieCinemaFile));
                String movieLine;

                ArrayList<String> movieList = new ArrayList<>();
                while ((movieLine = movieReader.readLine()) != null) {
                    movieList.add(movieLine);
                }
                movieReader.close();

                for (int i = 0; i < movieList.size(); i++) {
                    String[] array = movieList.get(i).split("■");
                    System.out.printf("%2d. %s\n", i + 1, array[1]);
                }

                System.out.println("==============================");
                System.out.println("0. 뒤로가기");
                System.out.println("1. 예매하기");
                System.out.println("==============================");
                System.out.print("입력 : ");
                String input = scan.nextLine();

                switch (input) {
                    case "0":
                        return;
                    case "1":
                        bookTicket(movieList); // 예매하기 메소드 호출
                        break;
                    default:
                        System.out.println("잘못된 입력입니다. 다시 입력해주세요.");
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void bookTicket(ArrayList<String> movieList) {
        while (true) {
            System.out.println("==============================");
            System.out.println("예매할 영화를 선택하세요.");
            System.out.println("==============================");

            for (int i = 0; i < movieList.size(); i++) {
                String[] array = movieList.get(i).split("■");
                System.out.printf("%d. %s\n", i + 1, array[1]);
            }

            System.out.println("==============================");
            System.out.println("0. 뒤로가기");
            System.out.println("==============================");
            System.out.print("입력 : ");

            try {
                int input = Integer.parseInt(scan.nextLine());

                if (input == 0) {
                    return;
                } else if (input >= 1 && input <= movieList.size()) {
                    // 여기에 예매 로직을 추가하면 됩니다.
                    String selectedMovie = movieList.get(input - 1);
                    System.out.printf("영화 [%s]를 예매합니다.\n", selectedMovie.split("■")[1]);
                    // 예매 정보를 저장하는 부분을 구현하세요.
                    break;
                } else {
                    System.out.println("잘못된 입력입니다. 다시 입력해주세요.");
                }
            } catch (NumberFormatException e) {
                System.out.println("숫자를 입력해주세요.");
            }
        }
    }
}
