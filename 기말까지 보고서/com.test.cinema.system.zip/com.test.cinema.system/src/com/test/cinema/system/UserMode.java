package com.test.cinema.system;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;

public class UserMode {

    private Scanner scanner = new Scanner(System.in);
    private ArrayList<String> movieList = new ArrayList<>();

    private File movieFile = new File("C:\\DDGCinema_data\\시스템_현재 상영 영화 목록.txt");

    public void displayMovies() {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(movieFile));
            String line;

            System.out.println("==============================");
            System.out.println("현재 상영 중인 영화 목록");
            System.out.println("==============================");

            while ((line = reader.readLine()) != null) {
                String[] movieInfo = line.split("■");
                System.out.printf("%s. %s\n", movieInfo[0], movieInfo[1]);
                movieList.add(line);
            }

            System.out.println("==============================");
            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void selectMovie() {
        System.out.print("영화 번호를 선택하세요: ");
        int selectedMovieIndex = scanner.nextInt();

        if (selectedMovieIndex > 0 && selectedMovieIndex <= movieList.size()) {
            String selectedMovie = movieList.get(selectedMovieIndex - 1);
            // You can add more functionalities here, such as checking showtimes or making reservations.
            System.out.println("선택한 영화: " + selectedMovie);
        } else {
            System.out.println("잘못된 입력입니다. 다시 시도해주세요.");
        }
    }

    public void run() {
        displayMovies();
        selectMovie();
    }

    public static void main(String[] args) {
        UserMode userMode = new UserMode();
        userMode.run();
    }
}
